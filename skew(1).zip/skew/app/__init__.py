from flask import Flask
from flask_restful import Api
import os


api = Api()

def create_app():
    app = Flask(__name__)

    app.config['DEBUG'] = True
    app.config['TEMP'] = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'static\\temp\\')  # 存储临时上传的文件
    app.config['IMAGE'] = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'static\\image\\')  # 存储较正后的文件
    app.config['SECRET_KEY'] = "23R5234LAJEFSFSDF"
    from app.image_rect import image_bp
    app.register_blueprint(image_bp)
    from app.index import index_bp
    app.register_blueprint(index_bp)

    return app
