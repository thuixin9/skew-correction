from aip import AipOcr

""" 你的 APPID AK SK """
APP_ID = '19924306'
API_KEY = 'wXGRydxn7E2NWPIUSpKz1rhF'
SECRET_KEY = 'p2AvnEbudG9FdHYN97DfMGxFhZFDXXX8'

client = AipOcr(APP_ID, API_KEY, SECRET_KEY)

""" 读取图片 """
def get_file_content(filePath):
    with open(filePath, 'rb') as fp:
        return fp.read()

def get_image_word(filePath):
    image = get_file_content(filePath)
    dict1=client.general(image)
    """ 调用通用文字识别, 图片参数为本地图片 """
    client.basicGeneral(image)

    """ 如果有可选参数 """
    options = {}
    options["language_type"] = "CHN_ENG"
    options["detect_direction"] = "true"
    options["detect_language"] = "true"
    options["probability"] = "true"

    """ 带参数调用通用文字识别, 图片参数为本地图片 """
    client.basicGeneral(image, options)

    url = "https//www.x.com/sample.jpg"

    """ 调用通用文字识别, 图片参数为远程url图片 """
    client.basicGeneralUrl(url)

    """ 如果有可选参数 """
    options = {}
    options["language_type"] = "CHN_ENG"
    options["detect_direction"] = "true"
    options["detect_language"] = "true"
    options["probability"] = "true"

    """ 带参数调用通用文字识别, 图片参数为远程url图片 """
    client.basicGeneralUrl(url, options)
    str_word_list = []
    for i in dict1['words_result']:
        # print(str(i['words']))
        str_word_list.append(i['words'])
        # print(str_word)
    return str_word_list

if __name__=='__main__':
    import os
    print(os.getcwd())
    words = get_image_word('../static/5.png')
    print('*'*30)
    print(words)
    print('*' * 30)