from .scan2 import ImgCorrect
from . import image_bp
from flask import request
from flask import current_app
from flask import flash
import cv2
from .myapi import get_image_word
import os
from flask import render_template
import datetime

@image_bp.route('/words', methods=['GET','POST'])
def get_words():
    """
    前端上传图片数据
    保存的到本地文件
    :return:
    """
    start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    image_data = request.files.get('image')

    if not image_data:
        return '参数缺失'
    filename = image_data.filename
    print(filename)
    file_save_temp_path = current_app.config.get('TEMP')
    if os.path.exists(os.path.join(file_save_temp_path, filename)):
        os.remove(os.path.join(file_save_temp_path, filename))  # 删除旧图片
    image_data.save(os.path.join(file_save_temp_path, filename))
    filename1 = filename
    im = cv2.imread(os.path.join(file_save_temp_path, filename))  # 使用函数cv2.imread(filepath,flags)读入图片
    imgcorrect = ImgCorrect(im)  # 创建一个对象
    lines_img = imgcorrect.img_lines()
    file_save_path = current_app.config.get('IMAGE')

    if os.path.exists(os.path.join(file_save_path, filename)):
        os.remove(os.path.join(file_save_path, filename))  # 删除旧图片
    if lines_img is None:
        imgRotation = imgcorrect.rotate_image(0)
        cv2.imwrite(os.path.join(file_save_path, filename), imgRotation)
    else:
        degree = imgcorrect.search_lines()
        imgRotation=imgcorrect.rotate_image(degree)
        cv2.imwrite(os.path.join(file_save_path, filename), imgRotation)
    filename2= filename
    try:
        words_list = get_image_word(os.path.join(file_save_path, filename))
    except Exception as e:
        flash('图片识别超时')
        return render_template('post_image.html')
    # print(words)
    end_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return render_template('data_show.html', words=words_list,filename1=filename1, filename2=filename2, start_time=start_time, end_time=end_time)
