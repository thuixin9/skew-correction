from flask import Blueprint

image_bp = Blueprint('image',__name__,url_prefix='/image')

from .rest_routing import *